package com.cognizant.user_identity_service.entity;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="User_Database")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString

  
public class UserCredentials {
	  @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	  private int user_Id;
	  private String userName;
	  private String userEmail;
	  private String userAddress;
	  private String userPassword ;
	  private int userPhoneNumber;
	  

}
