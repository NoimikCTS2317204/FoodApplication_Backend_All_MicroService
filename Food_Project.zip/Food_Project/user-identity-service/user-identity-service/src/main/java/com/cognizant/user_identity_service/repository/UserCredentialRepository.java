package com.cognizant.user_identity_service.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.user_identity_service.entity.UserCredentials;

public interface UserCredentialRepository extends JpaRepository<UserCredentials, Integer> {

	

	Optional<UserCredentials> findByUserName(String userName);

	

}
