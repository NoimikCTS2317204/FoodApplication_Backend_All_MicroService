package com.cognizant.user_identity_service.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.user_identity_service.dto.AuthRequest;
import com.cognizant.user_identity_service.entity.UserCredentials;
import com.cognizant.user_identity_service.service.AuthService;

@RestController
@RequestMapping("/auth")
@CrossOrigin("*")

public class AuthController {
	
	@Autowired
	private AuthService authService;
	
	@Autowired
	private AuthenticationManager authManager;
	
	
	
	 @PostMapping("/register")
	    public ResponseEntity<Map<String, String>> addNewUser(@RequestBody UserCredentials user) {
	        System.out.printf("Hey there from user service ++++++ %s%n", user);
	        String result = authService.SaveUser(user);
	        System.out.println(result);
	        
	        Map<String, String> response = new HashMap<>();
	        response.put("message", result);
	        
	        return new ResponseEntity<>(response, HttpStatus.OK);
	    }

	@PostMapping("/token")
	public Map<String, String> getToken(@RequestBody AuthRequest authRequest) {
	    Authentication authenticate = authManager.authenticate(
	        new UsernamePasswordAuthenticationToken(authRequest.getUserName(), authRequest.getUserPassword())
	    );
	    if (authenticate.isAuthenticated()) {
	    	System.out.println("User logged in ");
	        String token = authService.GenerateToken(authRequest.getUserName());
	        Map<String, String> response = new HashMap<>();
	        response.put("token", token);
	        return response;
	    } else {
	        throw new RuntimeException("User is Invalid");
	    }
	}
	

    @GetMapping("/validate")
    public String validateToken(@RequestParam("token") String token) {
    	authService.ValidateToken(token);
        return "Token is valid";
    }
    

    
    
    
    
    
    
    
    
    
    
    @GetMapping("/getAllUser")
    public List<UserCredentials> getAllUser() {
    	return authService.allUsers();
    }
	
	

}
