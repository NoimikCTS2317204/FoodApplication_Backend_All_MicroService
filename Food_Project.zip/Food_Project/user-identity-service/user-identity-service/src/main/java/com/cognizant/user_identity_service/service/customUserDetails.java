package com.cognizant.user_identity_service.service;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.cognizant.user_identity_service.entity.UserCredentials;

public class customUserDetails implements UserDetails {

	
	
	
	  private String userName;
	  private String userPassword ;
	  
	  
	  public customUserDetails(UserCredentials usercredential) {
		  this.userName=usercredential.getUserName();
		  this.userPassword=usercredential.getUserPassword();
		  
	  }
	  
	  
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return userPassword;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return userName;
	}

}
